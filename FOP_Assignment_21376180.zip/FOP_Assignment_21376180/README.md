## Synopsis 

Final Assignment of Fundamental of Programming

Date : 30/5/2023 

  
## Contents 

README file available for assignment

FOP_Assignment_21376180/background.py
FOP_Assignment_21376180/lights.py
FOP_Assignment_21376180/props.py
FOP_Assignment_21376180/smokemachine.py
FOP_Assignment_21376180/calling.py
FOP_Assignment_21376180/image.jpg



background.py: This code simulates the backgound image that is require for the stage.
calling.py : This code calls all the classes such as lights, smokemachine, background, props and run and simulates the program.
smokemachine.py: This code simulates the smoke and creates the foggy environment for the concert stage.
lights.py : This code create and scatter the colorful lights in the stage and changes the color in the stage.
background.py : This code creates the background image for the stage to enhance the stage and makes interactive.

## Dependencies 
numpy, matplotlib, props.py, lights.py, background.py, calling.py, smokemachine.py





## Version information 

<30/05/2023> -Final version of FOP Assignment
 

 
